# SOL Scalping Bot

Bot de scalping 1D pentru SOL/USDT care:
- Primește semnale de la TradingView (webhook)
- Trimite notificări în Telegram
- Execută ordine pe Bybit Testnet

## Deploy pe Render
1. Creează repo GitHub și conectează-l la [Render.com](https://render.com)
2. Adaugă variabilele din `.env.example`
3. Deploy & Ready!
